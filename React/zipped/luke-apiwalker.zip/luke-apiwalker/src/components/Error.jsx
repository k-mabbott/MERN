import React from 'react'

const Error = () => {
  return (
    <div>
        <img width={512}  src='https://lumiere-a.akamaihd.net/v1/images/image_9797b844.jpeg?region=0,125,1536,614' alt="Kenobi" />
        <p>These are not the droid you are looking for</p>
    </div>
  )
}

export default Error