
import React from 'react';
import styles from './Advertisement.module.css'


const Advertisement = () => {
    return(
        <div className={styles.add}>
            <p>Advertisement</p>
        </div>
    );
}
export default Advertisement;
