

import styles from './SubContents.module.css'

const SubContents = () => {
    return(
        <div className={styles.sub}>
            <p>Sub Content</p>
        </div>
    );
}
export default SubContents;